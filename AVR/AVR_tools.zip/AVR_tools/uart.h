#pragma once

void printf_init(void);
